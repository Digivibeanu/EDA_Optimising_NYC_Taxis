#!/usr/bin/env python
# coding: utf-8

# # **New York City Yellow Taxi Data**

# ## Objective
# In this case study you will be learning exploratory data analysis (EDA) with the help of a dataset on yellow taxi rides in New York City. This will enable you to understand why EDA is an important step in the process of data science and machine learning.

# ## **Problem Statement**
# As an analyst at an upcoming taxi operation in NYC, you are tasked to use the 2023 taxi trip data to uncover insights that could help optimise taxi operations. The goal is to analyse patterns in the data that can inform strategic decisions to improve service efficiency, maximise revenue, and enhance passenger experience.

# ## Tasks
# You need to perform the following steps for successfully completing this assignment:
# 1. Data Loading
# 2. Data Cleaning
# 3. Exploratory Analysis: Bivariate and Multivariate
# 4. Creating Visualisations to Support the Analysis
# 5. Deriving Insights and Stating Conclusions

# ---

# **NOTE:** The marks given along with headings and sub-headings are cumulative marks for those particular headings/sub-headings.<br>
# 
# The actual marks for each task are specified within the tasks themselves.
# 
# For example, marks given with heading *2* or sub-heading *2.1* are the cumulative marks, for your reference only. <br>
# 
# The marks you will receive for completing tasks are given with the tasks.
# 
# Suppose the marks for two tasks are: 3 marks for 2.1.1 and 2 marks for 3.2.2, or
# * 2.1.1 [3 marks]
# * 3.2.2 [2 marks]
# 
# then, you will earn 3 marks for completing task 2.1.1 and 2 marks for completing task 3.2.2.
# 

# ---

# ## Data Understanding
# The yellow taxi trip records include fields capturing pick-up and drop-off dates/times, pick-up and drop-off locations, trip distances, itemized fares, rate types, payment types, and driver-reported passenger counts.
# 
# The data is stored in Parquet format (*.parquet*). The dataset is from 2009 to 2024. However, for this assignment, we will only be using the data from 2023.
# 
# The data for each month is present in a different parquet file. You will get twelve files for each of the months in 2023.
# 
# The data was collected and provided to the NYC Taxi and Limousine Commission (TLC) by technology providers like vendors and taxi hailing apps. <br>
# 
# You can find the link to the TLC trip records page here: https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page

# ###  Data Description
# You can find the data description here: [Data Dictionary](https://www.nyc.gov/assets/tlc/downloads/pdf/data_dictionary_trip_records_yellow.pdf)

# **Trip Records**
# 
# 
# 
# |Field Name       |description |
# |:----------------|:-----------|
# | VendorID | A code indicating the TPEP provider that provided the record. <br> 1= Creative Mobile Technologies, LLC; <br> 2= VeriFone Inc. |
# | tpep_pickup_datetime | The date and time when the meter was engaged.  |
# | tpep_dropoff_datetime | The date and time when the meter was disengaged.   |
# | Passenger_count | The number of passengers in the vehicle. <br> This is a driver-entered value. |
# | Trip_distance | The elapsed trip distance in miles reported by the taximeter. |
# | PULocationID | TLC Taxi Zone in which the taximeter was engaged |
# | DOLocationID | TLC Taxi Zone in which the taximeter was disengaged |
# |RateCodeID |The final rate code in effect at the end of the trip.<br> 1 = Standard rate <br> 2 = JFK <br> 3 = Newark <br>4 = Nassau or Westchester <br>5 = Negotiated fare <br>6 = Group ride |
# |Store_and_fwd_flag |This flag indicates whether the trip record was held in vehicle memory before sending to the vendor, aka “store and forward,” because the vehicle did not have a connection to the server.  <br>Y= store and forward trip <br>N= not a store and forward trip |
# |Payment_type| A numeric code signifying how the passenger paid for the trip. <br> 1 = Credit card <br>2 = Cash <br>3 = No charge <br>4 = Dispute <br>5 = Unknown <br>6 = Voided trip |
# |Fare_amount| The time-and-distance fare calculated by the meter. <br>Extra Miscellaneous extras and surcharges.  Currently, this only includes the 0.50 and 1 USD rush hour and overnight charges. |
# |MTA_tax |0.50 USD MTA tax that is automatically triggered based on the metered rate in use. |
# |Improvement_surcharge | 0.30 USD improvement surcharge assessed trips at the flag drop. The improvement surcharge began being levied in 2015. |
# |Tip_amount |Tip amount – This field is automatically populated for credit card tips. Cash tips are not included. |
# | Tolls_amount | Total amount of all tolls paid in trip.  |
# | total_amount | The total amount charged to passengers. Does not include cash tips. |
# |Congestion_Surcharge |Total amount collected in trip for NYS congestion surcharge. |
# | Airport_fee | 1.25 USD for pick up only at LaGuardia and John F. Kennedy Airports|
# 
# Although the amounts of extra charges and taxes applied are specified in the data dictionary, you will see that some cases have different values of these charges in the actual data.

# **Taxi Zones**
# 
# Each of the trip records contains a field corresponding to the location of the pickup or drop-off of the trip, populated by numbers ranging from 1-263.
# 
# These numbers correspond to taxi zones, which may be downloaded as a table or map/shapefile and matched to the trip records using a join.
# 
# This is covered in more detail in later sections.

# ---

# ## **1** Data Preparation
# 
# <font color = red>[5 marks]</font> <br>

# ### Import Libraries

# In[67]:


# Import warnings
import warnings
warnings.filterwarnings('ignore')


# In[69]:


# Import the libraries you will be using for analysis
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns


# In[70]:


# Recommended versions
# numpy version: 1.26.4
# pandas version: 2.2.2
# matplotlib version: 3.10.0
# seaborn version: 0.13.2

# Check versions
print("numpy version:", np.__version__)
print("pandas version:", pd.__version__)
print("matplotlib version:", plt.matplotlib.__version__)
print("seaborn version:", sns.__version__)


# ### **1.1** Load the dataset
# <font color = red>[5 marks]</font> <br>

# You will see twelve files, one for each month.
# 
# To read parquet files with Pandas, you have to follow a similar syntax as that for CSV files.
# 
# `df = pd.read_parquet('file.parquet')`

# In[ ]:


# Try loading one file

# df = pd.read_parquet('2023-1.parquet')
# df.info()


# How many rows are there? Do you think handling such a large number of rows is computationally feasible when we have to combine the data for all twelve months into one?
# 
# To handle this, we need to sample a fraction of data from each of the files. How to go about that? Think of a way to select only some portion of the data from each month's file that accurately represents the trends.

# #### Sampling the Data
# > One way is to take a small percentage of entries for pickup in every hour of a date. So, for all the days in a month, we can iterate through the hours and select 5% values randomly from those. Use `tpep_pickup_datetime` for this. Separate date and hour from the datetime values and then for each date, select some fraction of trips for each of the 24 hours.
# 
# To sample data, you can use the `sample()` method. Follow this syntax:
# 
# ```Python
# # sampled_data is an empty DF to keep appending sampled data of each hour
# # hour_data is the DF of entries for an hour 'X' on a date 'Y'
# 
# sample = hour_data.sample(frac = 0.05, random_state = 42)
# # sample 0.05 of the hour_data
# # random_state is just a seed for sampling, you can define it yourself
# 
# sampled_data = pd.concat([sampled_data, sample]) # adding data for this hour to the DF
# ```
# 
# This *sampled_data* will contain 5% values selected at random from each hour.
# 
# Note that the code given above is only the part that will be used for sampling and not the complete code required for sampling and combining the data files.
# 
# Keep in mind that you sample by date AND hour, not just hour. (Why?)

# ---

# **1.1.1** <font color = red>[5 marks]</font> <br>
# Figure out how to sample and combine the files.

# **Note:** It is not mandatory to use the method specified above. While sampling, you only need to make sure that your sampled data represents the overall data of all the months accurately.

# In[ ]:


# Sample the data
# It is recommmended to not load all the files at once to avoid memory overload


# In[ ]:


# from google.colab import drive
# drive.mount('/content/drive')


# In[91]:


# Take a small percentage of entries from each hour of every date.
# Iterating through the monthly data:
#   read a month file -> day -> hour: append sampled data -> move to next hour -> move to next day after 24 hours -> move to next month file
# Create a single dataframe for the year combining all the monthly data

# Select the folder having data files
import os

# Select the folder having data files
os.chdir(r"C:\Users\Anu\Downloads\Datasets and Dictionary-NYC\Datasets and Dictionary\trip_records")

# Create a list of all the twelve files to read
file_list = os.listdir()

# initialise an empty dataframe
sampled_df = pd.DataFrame()


# iterate through the list of files and sample one by one:
for file_name in file_list:
    try:
        # file path for the current file
        file_path = os.path.join(os.getcwd(), file_name)

        # Reading the current file
        df = pd.read_parquet(file_path)

        df['tpep_pickup_datetime'] = pd.to_datetime(df['tpep_pickup_datetime'])

        df['date'] = df['tpep_pickup_datetime'].dt.date
        df['hour'] = df['tpep_pickup_datetime'].dt.hour

        # We will store the sampled data for the current date in this df by appending the sampled data from each hour to this
        # After completing iteration through each date, we will append this data to the final dataframe.
        sampled_data = pd.DataFrame()

        # Loop through dates and then loop through every hour of each date
        for date in df['date'].unique():
            date_data = df[df['date'] == date]

            # Iterate through each hour of the selected date
            for hour in range(24):
                hour_data = date_data[date_data['hour'] == hour]

                # Sample 5% of the hourly data randomly
                if not hour_data.empty:
                    sample = hour_data.sample(frac=0.0075, random_state=42)

                # add data of this hour to the dataframe
                sampled_data = pd.concat([sampled_data, sample])

        # Concatenate the sampled data of all the dates to a single dataframe
        sampled_df = pd.concat([sampled_df, sampled_data])

    except Exception as e:
        print(f"Error reading file {file_name}: {e}")


# In[92]:


sampled_df.info()


# After combining the data files into one DataFrame, convert the new DataFrame to a CSV or parquet file and store it to use directly.
# 
# Ideally, you can try keeping the total entries to around 250,000 to 300,000.

# In[93]:


# Store the df in csv/parquet
sampled_df.to_csv("Sampled_2023.csv",index=False)


# ## **2** Data Cleaning
# <font color = red>[30 marks]</font> <br>

# Now we can load the new data directly.

# In[94]:


# Load the new data file
df1 = pd.read_csv("Sampled_2023.csv")


# In[95]:


# df.head()
df1.head()


# In[96]:


df1.info()


# #### **2.1** Fixing Columns
# <font color = red>[10 marks]</font> <br>
# 
# Fix/drop any columns as you seem necessary in the below sections

# **2.1.1** <font color = red>[2 marks]</font> <br>
# 
# Fix the index and drop unnecessary columns

# In[97]:


# Fix the index and drop any columns that are not needed
df1.isnull().sum()


# Seeing high number of percentage of missing values with object data decided to drop out store_and_fwd_flag column

# In[98]:


df1 = df1.drop('store_and_fwd_flag',axis = 1)


# In[99]:


df1.head()


# **2.1.2** <font color = red>[3 marks]</font> <br>
# There are two airport fee columns. This is possibly an error in naming columns. Let's see whether these can be combined into a single column.

# In[100]:


# Combine the two airport fee columns
df1['airport_fee'] = df1['Airport_fee'] + df1['airport_fee']
df1.Airport_fee.value_counts()


# **2.1.3** <font color = red>[5 marks]</font> <br>
# Fix columns with negative (monetary) values

# In[101]:


# check where values of fare amount are negative
df1[df1['fare_amount'] < 0]


# Did you notice something different in the `RatecodeID` column for above records?

# In[102]:


# Analyse RatecodeID for the negative fare amounts
df1[df1['RatecodeID'] < 0]


# In[103]:


# Find which columns have negative values
df1.columns


# In[104]:


df1[(df1[['extra', 'mta_tax', 'tip_amount', 'tolls_amount', 'improvement_surcharge', 'total_amount',
        'congestion_surcharge', 'Airport_fee']] < 0).any(axis=1)]


# Miscellaneous, Extra charges is only showing negative values. Planning to take care of it later in the calculation.

# In[105]:


# fix these negative values
df1['extra'].value_counts()


# ### **2.2** Handling Missing Values
# <font color = red>[10 marks]</font> <br>

# **2.2.1**  <font color = red>[2 marks]</font> <br>
# Find the proportion of missing values in each column
# 
# 
# 

# In[106]:


# Find the proportion of missing values in each column
100*df1.isnull().mean()


# **2.2.2**  <font color = red>[3 marks]</font> <br>
# Handling missing values in `passenger_count`

# In[107]:


# Display the rows with null values
# Impute NaN values in 'passenger_count'
df1[df1['passenger_count'].isnull()]


# In[108]:


df1['passenger_count'] = df1['passenger_count'].fillna(0)
df1['passenger_count'].isnull().sum()


# Did you find zeroes in passenger_count? Handle these.

# In[110]:


df1[df1['passenger_count'] == 0]


# Since Mode and Median value of passenger count is 1, decided to substitute

# In[111]:


df1['passenger_count'].mode()


# In[112]:


df1['passenger_count'].median()


# In[120]:


df1['passenger_count'] = df1['passenger_count'].replace(0, 1)
df1.head()


# **2.2.3**  <font color = red>[2 marks]</font> <br>
# Handle missing values in `RatecodeID`

# In[119]:


# Fix missing values in 'RatecodeID'
df1['RatecodeID'].isnull().sum()


# In[121]:


df1['RatecodeID'].median()


# In[123]:


df1['RatecodeID'] = df1['RatecodeID'].astype(float).fillna(1.0)
df1['RatecodeID'].isnull().sum()


# **2.2.4**  <font color = red>[3 marks]</font> <br>
# Impute NaN in `congestion_surcharge`

# In[124]:


# handle null values in congestion_surcharge
df1['congestion_surcharge'].isnull().sum()


# In[125]:


df1['congestion_surcharge'].value_counts()


# In[126]:


df1['congestion_surcharge'].median()


# In[129]:


df1['congestion_surcharge'] = df1['congestion_surcharge'].fillna(2.5)
df1['congestion_surcharge'].isnull().sum()


# Are there missing values in other columns? Did you find NaN values in some other set of columns? Handle those missing values below.

# In[130]:


# Handle any remaining missing values
df1.isnull().sum()


# In[131]:


df1['Airport_fee'].mean()


# In[132]:


df1['Airport_fee'].value_counts()


# In[134]:


df1['Airport_fee'] = df1['Airport_fee'].fillna(0.0)
df1['airport_fee'].value_counts(dropna=False)


# In[135]:


df1 = df1.drop('airport_fee' , axis = 1)
df1.isnull().sum()


# ### **2.3** Handling Outliers
# <font color = red>[10 marks]</font> <br>

# Before we start fixing outliers, let's perform outlier analysis.

# In[136]:


# Describe the data and check if there are any potential outliers present
# Check for potential out of place values in various columns
df1.describe()


# **2.3.1**  <font color = red>[10 marks]</font> <br>
# Based on the above analysis, it seems that some of the outliers are present due to errors in registering the trips. Fix the outliers.
# 
# Some points you can look for:
# - Entries where `trip_distance` is nearly 0 and `fare_amount` is more than 300
# - Entries where `trip_distance` and `fare_amount` are 0 but the pickup and dropoff zones are different (both distance and fare should not be zero for different zones)
# - Entries where `trip_distance` is more than 250  miles.
# - Entries where `payment_type` is 0 (there is no payment_type 0 defined in the data dictionary)
# 
# These are just some suggestions. You can handle outliers in any way you wish, using the insights from above outlier analysis.

# How will you fix each of these values? Which ones will you drop and which ones will you replace?

# First, let us remove 7+ passenger counts as there are very less instances.

# In[138]:


df1['passenger_count'].value_counts()


# In[141]:


# remove passenger_count > 6
df1 = df1[df1['passenger_count'] <= 6]
df1['passenger_count'].value_counts()


# In[142]:


# Continue with outlier handling
df1['trip_distance'].value_counts()


# In[143]:


# Do any columns need standardising?
df1[df1['trip_distance'] <= 250]


# In[144]:


df1[df1['tip_amount'] > 100]['tip_amount']


# In[145]:


df1['payment_type'] = df1['payment_type'].replace(0,1)


# ## **3** Exploratory Data Analysis
# <font color = red>[90 marks]</font> <br>

# In[146]:


df.columns.tolist()


# #### **3.1** General EDA: Finding Patterns and Trends
# <font color = red>[40 marks]</font> <br>

# **3.1.1** <font color = red>[3 marks]</font> <br>
# Categorise the varaibles into Numerical or Categorical.
# * `VendorID`:
# * `tpep_pickup_datetime`:
# * `tpep_dropoff_datetime`:
# * `passenger_count`:
# * `trip_distance`:
# * `RatecodeID`:
# * `PULocationID`:
# * `DOLocationID`:
# * `payment_type`:
# * `pickup_hour`:
# * `trip_duration`:
# 
# 
# The following monetary parameters belong in the same category, is it categorical or numerical?
# 
# 
# * `fare_amount`
# * `extra`
# * `mta_tax`
# * `tip_amount`
# * `tolls_amount`
# * `improvement_surcharge`
# * `total_amount`
# * `congestion_surcharge`
# * `airport_fee`

# # Categorical Variable
# Variables that fall into categories VendorID: represents the vendor codeid; as a result, it is categorical in nature even if it is numerical. PULocationID is categorical in nature since it represents a certain taxi zone. RatecodeID: this is a categorical code that also serves as a standard code for several airports, such as JKF and Newark. Payment_type: it is categorical since a payment type is represented by each numerical value.Although DOLocationID is numerical, it is categorical in nature because it represents a particular taxi zone where the passenger disengaged. 

# # Numerical Variable
# tpep_dropoff_datetime: a variable valueThe values for _hour and trip_duration are both numerical in nature. 
# trip_distance: a numerical value in nature that can change;
# tpep_pickup_datetime: a number that can have a range of values 
# passenger_count: a numerical value that can fluctuate
# 
# Tolls_amount, fare_amount, additional mta_tax, tip_amount, congestion_surcharge, total_amount, and airport_fee   
# Since they all represent a quantity, they are all numerical variables.

# ##### Temporal Analysis

# **3.1.2** <font color = red>[5 marks]</font> <br>
# Analyse the distribution of taxi pickups by hours, days of the week, and months.

# In[159]:


# Find and show the hourly trends in taxi pickups
df1.groupby('hour')['tpep_pickup_datetime'].count().plot(kind='bar', title='Hourly Taxi Pickup')
plt.show()


# In[149]:


# Find and show the daily trends in taxi pickups (days of the week)
df1['tpep_pickup_datetime'] = pd.to_datetime(df1['tpep_pickup_datetime'])
#Extracting day of the week 
df1['day_of_week'] = df1['tpep_pickup_datetime'].dt.dayofweek
#Getting the count of daily_pickups 
daily_pickups = df1.groupby('day_of_week')['tpep_pickup_datetime'].count()
#Creating a list of names of the week 
day_names = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
# Mapping the day _names to the index of daily_pickups 
daily_pickups.index = daily_pickups.index.map(lambda x: day_names[x])


# In[161]:


daily_pickups.plot(kind = 'bar' , title = 'Daily Taxi Pickup Trends')
plt.xlabel('Day of Week')
plt.ylabel('Number of Pickups')
plt.show()


# Maximum pickups of daily trends are on Wednesday, Thursday and Saturday

# In[162]:


# Show the monthly trends in pickups
df1['tpep_pickup_datetime'].value_counts()


# In[163]:


df1['tpep_pickup_datetime'] = pd.to_datetime(df1['tpep_pickup_datetime'])
# Extracting day of the week 
df1['month_of_year'] = df1['tpep_pickup_datetime'].dt.month
# Getting the count of daily pickups 
monthly_pickups = df1.groupby('month_of_year')['tpep_pickup_datetime'].count()
# Creating a list of name of the months
month_names = ['January','February','March','April','May','June','July', 'August','September', 'October' , 'November' , 'December' ]
# Mapping the month_names to the index of daily_pickups 
monthly_pickups.index = monthly_pickups.index.map(lambda x: month_names[x -1])


# In[165]:


monthly_pickups.plot(kind = 'bar' , title = 'Monthly Taxi Pickup Trends')
plt.xlabel('Month of Year')
plt.ylabel('Number of Pickups')
plt.show()


# Higher pickup rates in the months of March, May,June, October and December

# ##### Financial Analysis

# Take a look at the financial parameters like `fare_amount`, `tip_amount`, `total_amount`, and also `trip_distance`. Do these contain zero/negative values?

# In[166]:


# Analyse the above parameters
df1[df1[['fare_amount','tip_amount','total_amount','trip_distance']] < 0]


# In[167]:


negative_value = (df1[['fare_amount','tip_amount','total_amount','trip_distance']] < 0).any().any()
print(negative_value)


# In[168]:


df1[['fare_amount','tip_amount','total_amount','trip_distance']].info()


# In[169]:


df1[['fare_amount','tip_amount','total_amount','trip_distance']].isnull().sum()


# In[171]:


df1[df1[['fare_amount','tip_amount','total_amount','trip_distance']] < 0] = 0


# In[ ]:





# Do you think it is beneficial to create a copy DataFrame leaving out the zero values from these?

# **3.1.3** <font color = red>[2 marks]</font> <br>
# Filter out the zero values from the above columns.
# 
# **Note:** The distance might be 0 in cases where pickup and drop is in the same zone. Do you think it is suitable to drop such cases of zero distance?

# In[172]:


# Create a df with non zero entries for the selected parameters.
df1[df1[['fare_amount','tip_amount','total_amount','trip_distance']] != 0]


# In[173]:


df1[df1['trip_distance'] == 0]


# Checking if any negative values are present or not

# In[174]:


negative_values = (df1['tip_amount'] < 0).any().any()
print(negative_values)


# In[176]:


negative_values= (df1['fare_amount'] < 0).any().any()
print(negative_values)


# In[177]:


negative_values = (df1['trip_distance'] < 0).any().any()
print(negative_values)


# In[178]:


negative_values = (df1['total_amount'] < 0).any().any()
print(negative_values)


# In[179]:


df1.trip_distance.replace(0,1.8)


# **3.1.4** <font color = red>[3 marks]</font> <br>
# Analyse the monthly revenue (`total_amount`) trend

# In[180]:


# Group data by month and analyse monthly revenue
df1.groupby('month_of_year')['total_amount'].sum().plot.bar()
plt.show()


# **3.1.5** <font color = red>[3 marks]</font> <br>
# Show the proportion of each quarter of the year in the revenue

# In[181]:


df1['quarter'] = df1['tpep_pickup_datetime'].dt.quarter


# In[182]:


# Calculate proportion of each quarter
revenue_by_quarter = df1.groupby('quarter')['total_amount'].sum().reset_index()
total_revenue = revenue_by_quarter['total_amount'].sum()
revenue_by_quarter['proportions'] = (revenue_by_quarter['total_amount']/total_revenue)*100
print("Revenue Proportion by Quarter:")
print(revenue_by_quarter[['quarter', 'proportions']])


# In[186]:


plt.figure(figsize=(8, 6))
plt.bar(revenue_by_quarter['quarter'], revenue_by_quarter['proportions'])
plt.title("Proportion of Revenue by Quarter")
plt.xlabel("Quarter")
plt.ylabel("Proportion (%)")
plt.show()


# Shows higher revenue in the second quarter

# **3.1.6** <font color = red>[3 marks]</font> <br>
# Visualise the relationship between `trip_distance` and `fare_amount`. Also find the correlation value for these two.
# 
# **Hint:** You can leave out the trips with trip_distance = 0

# In[187]:


# Show how trip fare is affected by distance
sns.scatterplot(data = df1[df1['trip_distance'] > 0] , x = 'fare_amount' , y = 'trip_distance' )
plt.title('Relation Between Trip Distance and Fare Amount')
plt.xlabel( 'Fare Amount')
plt.ylabel('Trip Distance')
plt.show()


# Both the fare amount of Trip distance shows a positive correlation for a fare amount of 300 and a distance of upto 75

# **3.1.7** <font color = red>[5 marks]</font> <br>
# Find and visualise the correlation between:
# 1. `fare_amount` and trip duration (pickup time to dropoff time)
# 2. `fare_amount` and `passenger_count`
# 3. `tip_amount` and `trip_distance`

# In[188]:


# Show relationship between fare and trip duration
df1['tpep_pickup_datetime'] = pd.to_datetime(df1['tpep_pickup_datetime'])
df1['tpep_dropoff_datetime'] = pd.to_datetime(df1['tpep_dropoff_datetime'])
df1['trip_duration'] = (df1['tpep_dropoff_datetime'] - df1['tpep_pickup_datetime']).dt.total_seconds()
df1['trip_duration'] = df1['trip_duration']/60


# In[189]:


sns.scatterplot(data = df1 , x = 'fare_amount', y = 'trip_duration')
plt.title('Relation Between Trip Duration and Fare Amount')
plt.xlabel( 'Fare Amount')
plt.ylabel('Trip Duration')
plt.show()


# In[191]:


# Show relationship between fare and number of passengers
sns.scatterplot(data = df1 , x = 'fare_amount', y = 'passenger_count')
plt.title('Relation Between Passenger Count and Fare Amount')
plt.xlabel( 'Fare Amount')
plt.ylabel('Passenger Count')
plt.show()


# In[193]:


# Show relationship between tip and trip distance
sns.scatterplot(data = df1 , x = 'fare_amount', y = 'tip_amount')
plt.title('Relation Between Tip Amount and Fare Amount')
plt.xlabel( 'Fare Amount')
plt.ylabel('Tip Amount')
plt.show()


# The graph shows that the amount of the tip and the amount of the fare are very positively correlated. It is evident that the fare amount is positive up to 400, which is equivalent to a tip amount of 60. Another captivating thing is that there are also two outliers. For fares under 200, a very high tip of 140 is appropriate; for fares beyond 800, there is no tip at all.

# In[194]:


correlation_columns = ['fare_amount', 'trip_duration', 'passenger_count', 'tip_amount', 'trip_distance']
correlation_matrix = df1[correlation_columns].corr()
print(correlation_matrix)


# In[196]:


sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", square=True)
plt.title( 'Correlation of Fare Amount , Trip Duration Passenger Count and Other Parameters')
plt.tight_layout()
plt.show()


# In[ ]:





# **3.1.8** <font color = red>[3 marks]</font> <br>
# Analyse the distribution of different payment types (`payment_type`)

# In[197]:


# Analyse the distribution of different payment types (payment_type).

payment_type_dist = df1['payment_type'].value_counts(normalize = True)*100
print(payment_type_dist)


# - 1= Credit card
# - 2= Cash
# - 3= No charge
# - 4= Dispute
# 
# 

# In[201]:


payment_type_counts = df1['payment_type'].value_counts()

plt.figure(figsize=(8, 5))
sns.barplot(x=payment_type_counts.values, y=payment_type_counts.index, orient='h')
plt.title('Payment Type Distribution')
plt.xlabel('Count')
plt.ylabel('Payment Type')
plt.tight_layout()
plt.show()


# As seen from the above graph the highest payment mode is credit card followed by cash payments

# ##### Geographical Analysis

# For this, you have to use the *taxi_zones.shp* file from the *taxi_zones* folder.
# 
# There would be multiple files inside the folder (such as *.shx, .sbx, .sbn* etc). You do not need to import/read any of the files other than the shapefile, *taxi_zones.shp*.
# 
# Do not change any folder structure - all the files need to be present inside the folder for it to work.
# 
# The folder structure should look like this:
# ```
# Taxi Zones
# |- taxi_zones.shp.xml
# |- taxi_zones.prj
# |- taxi_zones.sbn
# |- taxi_zones.shp
# |- taxi_zones.dbf
# |- taxi_zones.shx
# |- taxi_zones.sbx
# 
#  ```
# 
#  You only need to read the `taxi_zones.shp` file. The *shp* file will utilise the other files by itself.

# We will use the *GeoPandas* library for geopgraphical analysis
# ```
# import geopandas as gpd
# ```
# 
# More about geopandas and shapefiles: [About](https://geopandas.org/en/stable/about.html)
# 
# 
# Reading the shapefile is very similar to *Pandas*. Use `gpd.read_file()` function to load the data (*taxi_zones.shp*) as a GeoDataFrame. Documentation: [Reading and Writing Files](https://geopandas.org/en/stable/docs/user_guide/io.html)

# In[211]:


pip install geopandas


# **3.1.9** <font color = red>[2 marks]</font> <br>
# Load the shapefile and display it.

# In[221]:


# import geopandas as gpd
import geopandas as gpd


# In[233]:


zones = gpd.read_file("C:/Users/Anu/Downloads/Datasets and Dictionary-NYC/Datasets and Dictionary/taxi_zones")


# In[231]:


zones.head()


# Now, if you look at the DataFrame created, you will see columns like: `OBJECTID`,`Shape_Leng`, `Shape_Area`, `zone`, `LocationID`, `borough`, `geometry`.
# <br><br>
# 
# Now, the `locationID` here is also what we are using to mark pickup and drop zones in the trip records.
# 
# The geometric parameters like shape length, shape area and geometry are used to plot the zones on a map.
# 
# This can be easily done using the `plot()` method.

# In[234]:


print(zones.info())
zones.plot()


# Now, you have to merge the trip records and zones data using the location IDs.
# 
# 

# **3.1.10** <font color = red>[3 marks]</font> <br>
# Merge the zones data into trip data using the `locationID` and `PULocationID` columns.

# In[235]:


# Merge zones and trip records using locationID and PULocationID
df1.rename(columns = {'PULocationID' : 'LocationID'} , inplace = True)


# In[237]:


df2 = pd.merge(df1,zones , left_on='LocationID', right_on='LocationID', how = 'outer')


# In[238]:


df2.head()


# In[ ]:





# **3.1.11** <font color = red>[3 marks]</font> <br>
# Group data by location IDs to find the total number of trips per location ID

# In[239]:


# Group data by location and calculate the number of trips
trips_per_location = df2.groupby('LocationID')['LocationID'].count().reset_index(name='total_trips')
print(trips_per_location)


# **3.1.12** <font color = red>[2 marks]</font> <br>
# Now, use the grouped data to add number of trips to the GeoDataFrame.
# 
# We will use this to plot a map of zones showing total trips per zone.

# In[240]:


# Merge trip counts back to the zones GeoDataFrame

zones_with_trips = pd.merge(zones, trips_per_location, left_on='LocationID', right_on='LocationID', how='left')


# In[241]:


zones_with_trips.sort_values(by = 'total_trips' , ascending = False)


# The next step is creating a color map (choropleth map) showing zones by the number of trips taken.
# 
# Again, you can use the `zones.plot()` method for this. [Plot Method GPD](https://geopandas.org/en/stable/docs/reference/api/geopandas.GeoDataFrame.plot.html#geopandas.GeoDataFrame.plot)
# 
# But first, you need to define the figure and axis for the plot.
# 
# `fig, ax = plt.subplots(1, 1, figsize = (12, 10))`
# 
# This function creates a figure (fig) and a single subplot (ax)
# 
# ---

# After setting up the figure and axis, we can proceed to plot the GeoDataFrame on this axis. This is done in the next step where we use the plot method of the GeoDataFrame.
# 
# You can define the following parameters in the `zones.plot()` method:
# ```
# column = '',
# ax = ax,
# legend = True,
# legend_kwds = {'label': "label", 'orientation': "<horizontal/vertical>"}
# ```
# 
# To display the plot, use `plt.show()`.

# **3.1.13** <font color = red>[3 marks]</font> <br>
# Plot a color-coded map showing zone-wise trips

# In[242]:


# Define figure and axis
# Plot the map and display it
fig , ax = plt.subplots(1,1,figsize = (10,10))
zones_with_trips.plot(column = 'total_trips' , cmap='viridis', linewidth=0.5, ax=ax, edgecolor='0.8', legend=True)
ax.set_title('Choropleth Map of Trips per Zone')
plt.show()


# In[243]:


# can you try displaying the zones DF sorted by the number of trips?
zones_with_trips.sort_values(by = ['total_trips'] , ascending = False)


# Here we have completed the temporal, financial and geographical analysis on the trip records.
# 
# **Compile your findings from general analysis below:**

# You can consider the following points:
# 
# * Busiest hours, days and months
# * Trends in revenue collected
# * Trends in quarterly revenue
# * How fare depends on trip distance, trip duration and passenger counts
# * How tip amount depends on trip distance
# * Busiest zones
# 

# #### **3.2** Detailed EDA: Insights and Strategies
# <font color = red>[50 marks]</font> <br>

# Having performed basic analyses for finding trends and patterns, we will now move on to some detailed analysis focussed on operational efficiency, pricing strategies, and customer experience.

# ##### Operational Efficiency

# Analyze variations by time of day and location to identify bottlenecks or inefficiencies in routes

# **3.2.1** <font color = red>[3 marks]</font> <br>
# Identify slow routes by calculating the average time taken by cabs to get from one zone to another at different hours of the day.

# Speed on a route *X* for hour *Y* = (*distance of the route X / average trip duration for hour Y*)

# In[244]:


# Find routes which have the slowest speeds at different times of the day
df2 = df2[(df2['trip_duration'] > 0) & (df2['trip_distance'] > 0)]
df2 = df2[(df2['trip_duration'] > 0) & (df2['trip_duration'] < 10800)]  # 10800 seconds = 3 hours
df2['speed'] = df2['trip_distance'] / (df2['trip_duration'] / 3600)
route_speeds = df2.groupby(['LocationID', 'DOLocationID', 'hour'])['speed'].mean().reset_index()
slowest_routes_per_hour = route_speeds.loc[route_speeds.groupby('hour')['speed'].idxmin()]
print(slowest_routes_per_hour)


# How does identifying high-traffic, high-demand routes help us?

# **3.2.2** <font color = red>[3 marks]</font> <br>
# Calculate the number of trips at each hour of the day and visualise them. Find the busiest hour and show the number of trips for that hour.

# In[246]:


# Visualise the number of trips per hour and find the busiest hour
trips_per_hour = df2.groupby('hour').size()
df2['trips_per_hour'] = df2.groupby('hour')['hour'].count()
trips_per_hour.plot(kind = 'bar', figsize = (10,6))
plt.title('Number of Trips per Hour')
plt.xlabel('Hour of Day')
plt.ylabel('Number of Trips')
plt.show()


# In[247]:


busiest_hour =  trips_per_hour.idxmax()
print(f"The busiest hour is : {busiest_hour}")


# Remember, we took a fraction of trips. To find the actual number, you have to scale the number up by the sampling ratio.

# **3.2.3** <font color = red>[2 mark]</font> <br>
# Find the actual number of trips in the five busiest hours

# In[248]:


# Scale up the number of trips

# Fill in the value of your sampling fraction and use that to scale up the numbers
sample_fraction = 0.0075 
df2['scaled_up_trips'] = df2['trips_per_hour']/sample_fraction
# Finding trips count per hour
hourly_trip_counts = df2.groupby('hour')['scaled_up_trips'].sum()
busiest_hours = hourly_trip_counts.nlargest(5)
print("Five Busiest Hours:" , busiest_hours)


# **3.2.4** <font color = red>[3 marks]</font> <br>
# Compare hourly traffic pattern on weekdays. Also compare for weekend.

# In[249]:


# Compare traffic trends for the week days and weekends
df2.columns


# Classifying days as weekdays and weekends

# In[250]:


df2['pickup_hour'] = df2['tpep_pickup_datetime'].dt.hour
df2['day_type'] = df2['day_of_week'].apply(lambda x: 'Weekend' if x >= 5 else 'Weekday')
# Pickup hours for calculating the trip count
traffic_trends = df2.groupby(['pickup_hour', 'day_type']).size().reset_index(name='trip_count')
# Plotting the trends
plt.figure(figsize=(10, 6))
sns.lineplot(data=traffic_trends, x='pickup_hour', y='trip_count', hue='day_type', marker='o')
plt.title('Traffic Trends: Weekdays vs Weekends')
plt.xlabel('Hour of Day')
plt.ylabel('Number of Trips')
plt.xticks(range(0, 24))
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()


# What can you infer from the above patterns? How will finding busy and quiet hours for each day help us?

# In[251]:


df2['trips_per_hour'] = pd.to_numeric(df2['trips_per_hour'], errors='coerce')
hours_daily_counts = df2.groupby(['date','hour'])['trips_per_hour'].sum()
threshold = 10
busy_hours = hours_daily_counts[hours_daily_counts > threshold].groupby('date').idxmax()
quiet_hours = hours_daily_counts[hours_daily_counts <= threshold].groupby('date').idxmin()
print("Busiest Hours for Each Day:")
print(busy_hours)

print("\nQuietest Hours for Each Day:")
print(quiet_hours)


# **3.2.5** <font color = red>[3 marks]</font> <br>
# Identify top 10 zones with high hourly pickups. Do the same for hourly dropoffs. Show pickup and dropoff trends in these zones.

# In[252]:


# Find top 10 pickup and dropoff zones
zone_mapping = df2.groupby('LocationID')['zone'].first().to_dict()
df2['pick_up_zone'] = df2['LocationID'].map(zone_mapping)


# In[253]:


pick_up_zone_hourly_counts = df2.groupby(['pickup_hour', 'pick_up_zone']).size().reset_index(name='count')

top_10_pickup_zones_by_hour = pick_up_zone_hourly_counts.groupby('pickup_hour').apply(lambda x: x.nlargest(10, 'count')).reset_index(drop=True)

print(top_10_pickup_zones_by_hour)


# In[254]:


zone_mapping = df2.groupby('DOLocationID')['zone'].first().to_dict()
df2['drop_off_zone'] = df2['DOLocationID'].map(zone_mapping)


# In[255]:


drop_off_zone_counts = df2['drop_off_zone'].value_counts()
top_10_drop_off_zones = drop_off_zone_counts.nlargest(10)
print("Top 10 Drop-off Zones:")
print(top_10_drop_off_zones)


# **3.2.6** <font color = red>[3 marks]</font> <br>
# Find the ratio of pickups and dropoffs in each zone. Display the 10 highest (pickup/drop) and 10 lowest (pickup/drop) ratios.

# In[256]:


# Find the top 10 and bottom 10 pickup/dropoff ratios
pickup_counts = df2['pick_up_zone'].value_counts()
drop_off_counts = df2['drop_off_zone'].value_counts()
zone_ratios = pickup_counts.div(drop_off_counts).replace([np.inf, -np.inf], np.nan)
highest_ratios = zone_ratios.nlargest(10, keep='all')
lowest_ratios = zone_ratios[zone_ratios != 0].nsmallest(10, keep='all') 

print("10 Highest Pickup/Dropoff Ratios:")
print(highest_ratios)

print("\n10 Lowest Pickup/Dropoff Ratios:")
print(lowest_ratios)


# **3.2.7** <font color = red>[3 marks]</font> <br>
# Identify zones with high pickup and dropoff traffic during night hours (11PM to 5AM)

# In[257]:


# During night hours (11pm to 5am) find the top 10 pickup and dropoff zones
# Note that the top zones should be of night hours and not the overall top zones
night_hours_data = df2[(df2['hour'] >= 23) | (df2['hour'] <= 5)]
night_pickup_counts = night_hours_data['pick_up_zone'].value_counts()
night_dropoff_counts = night_hours_data['drop_off_zone'].value_counts()
top_pickup_zones = night_pickup_counts.nlargest(10)
top_dropoff_zones = night_dropoff_counts.nlargest(10)
print("Top 10 Pickup Zones during Night Hours:")
print(top_pickup_zones)

print("\nTop 10 Dropoff Zones during Night Hours:")
print(top_dropoff_zones)


# Now, let us find the revenue share for the night time hours and the day time hours. After this, we will move to deciding a pricing strategy.
# 
# **3.2.8** <font color = red>[2 marks]</font> <br>
# Find the revenue share for nighttime and daytime hours.

# In[258]:


# Filter for night hours (11 PM to 5 AM)
nighttime_hours = [23, 0, 1, 2, 3, 4, 5]
daytime_hours = list(range(6,23))
nighttime_data = df2[df2['hour'].isin(nighttime_hours)]
daytime_data = df2[df2['hour'].isin(daytime_hours)]
nighttime_revenue = nighttime_data['total_amount'].sum()
daytime_revenue = daytime_data['total_amount'].sum()
total_revenue = nighttime_revenue + daytime_revenue
nighttime_share = (nighttime_revenue / total_revenue) * 100
daytime_share = (daytime_revenue / total_revenue) * 100
print("Revenue Share:")
print(f"Nighttime: {nighttime_share:.2f}%")
print(f"Daytime: {daytime_share:.2f}%")


# ##### Pricing Strategy

# **3.2.9** <font color = red>[2 marks]</font> <br>
# For the different passenger counts, find the average fare per mile per passenger.
# 
# For instance, suppose the average fare per mile for trips with 3 passengers is 3 USD/mile, then the fare per mile per passenger will be 1 USD/mile.

# In[259]:


# Analyse the fare per mile per passenger for different passenger counts
filtered_df2 = df2[(df2['trip_distance'] > 0) & (df2['passenger_count'] > 0)].copy()
filtered_df2['fare_per_mile'] = filtered_df2['fare_amount']/filtered_df2['trip_distance']
filtered_df2['fare_per_mile_per_passenger'] = filtered_df2['fare_per_mile']/ filtered_df2['passenger_count']
average_fare_per_mile_per_passenger = filtered_df2.groupby('passenger_count')['fare_per_mile_per_passenger'].mean()
print('Average Fare Per Mile Per Passenger:')
print(average_fare_per_mile_per_passenger)


# **3.2.10** <font color = red>[3 marks]</font> <br>
# Find the average fare per mile by hours of the day and by days of the week

# In[260]:


# Compare the average fare per mile for different days and for different times of the day
average_fare_per_mile_per_hour = filtered_df2.groupby('hour')['fare_per_mile'].mean()
average_fare_per_mile_per_day = filtered_df2.groupby('day_of_week')['fare_per_mile'].mean()
print('Average Fare Per Mile Per Hour:' )
print(average_fare_per_mile_per_hour)
print('Average Fare Per Mile Per Day:')
print(average_fare_per_mile_per_day)


# **3.2.11** <font color = red>[3 marks]</font> <br>
# Analyse the average fare per mile for the different vendors for different hours of the day

# In[261]:


# Compare fare per mile for different vendors
average_fare_per_mile_per_hour_per_vendor = filtered_df2.groupby(['VendorID', 'hour'])['fare_per_mile'].mean().reset_index()
print("Average Fare per mile by vendor and hour of the day:")
print(average_fare_per_mile_per_hour_per_vendor)


# In[262]:


sns.scatterplot(data=average_fare_per_mile_per_hour_per_vendor, x="hour", y="fare_per_mile", hue="VendorID")
plt.title("Average Fare per Mile by Vendor and Hour")
plt.xlabel("Hour of Day")
plt.ylabel("Average Fare per Mile")
plt.show()


# **3.2.12** <font color = red>[5 marks]</font> <br>
# Compare the fare rates of the different vendors in a tiered fashion. Analyse the average fare per mile for distances upto 2 miles. Analyse the fare per mile for distances from 2 to 5 miles. And then for distances more than 5 miles.
# 

# In[ ]:


# Defining distance tiers


# Creating distance tiers first

# In[263]:


filtered_df2['distance_tiers'] = pd.cut(filtered_df2['trip_distance'] , bins = [0, 2, 5, float('inf')] , labels = ['upto 2 miles' ,'2 to 5 miles','more than 5 miles']) 
average_fare_by_vendor_tiers = filtered_df2.groupby(['VendorID', 'distance_tiers'], observed = False)['fare_per_mile'].mean().reset_index()
print('Average Fare per mile per vendor per distance category:')
print(average_fare_by_vendor_tiers)
sns.barplot(data = average_fare_by_vendor_tiers , x = 'distance_tiers' , y = 'fare_per_mile' , hue = 'VendorID')
plt.title('Average Fare by Mile Per Vendor Per Distance Category')
plt.xlabel('Distance Tiers by Miles')
plt.ylabel('Average Fare Per Mile')
plt.show()


# ##### Customer Experience and Other Factors

# **3.2.13** <font color = red>[5 marks]</font> <br>
# Analyse average tip percentages based on trip distances, passenger counts and time of pickup. What factors lead to low tip percentages?

# In[264]:


#  Analyze tip percentages based on distances, passenger counts and pickup times
filtered_df2['tip_percentage'] = filtered_df2['tip_amount'] / filtered_df2['total_amount']*100
average_tip_percentage = filtered_df2.groupby(['trip_distance' , 'passenger_count' , 'tpep_pickup_datetime'])['tip_percentage'].mean().reset_index()
print("Average Tip Percentage by Distance, Passenger Count, and Pickup Time")
print(average_tip_percentage)


# In[265]:


filtered_df2['tip_percentage'] = filtered_df2['tip_amount'] / filtered_df2['total_amount']*100
average_tip_percentage_hour = filtered_df2.groupby(['trip_distance' , 'passenger_count' , 'hour'])['tip_percentage'].mean().reset_index()
print("Average Tip Percentage by Distance, Passenger Count, and Hour")
print(average_tip_percentage_hour)


# Additional analysis [optional]: Let's try comparing cases of low tips with cases of high tips to find out if we find a clear aspect that drives up the tipping behaviours

# In[266]:


# Compare trips with tip percentage < 10% to trips with tip percentage > 25%
filtered_df2[filtered_df2['tip_percentage'] < 10].groupby('tip_percentage')['trips_per_hour'].count()


# In[267]:


filtered_df2[filtered_df2['tip_percentage'] > 25].groupby('tip_percentage')['trips_per_hour'].count()


# **3.2.14** <font color = red>[3 marks]</font> <br>
# Analyse the variation of passenger count across hours and days of the week.

# In[268]:


# See how passenger count varies across hours and days
average_passenger_per_day_per_hour = filtered_df2.groupby(['hour','day_of_week'])['passenger_count'].mean().reset_index()


# In[269]:


heatmap_data = average_passenger_per_day_per_hour.pivot_table(index="day_of_week", columns="hour", values="passenger_count")
plt.figure(figsize=(16, 10))
sns.heatmap(heatmap_data, cmap="YlGnBu", annot=True, fmt=".2f")
plt.title("Average Passenger Count by Hour and Day of the Week")
plt.xlabel("Hour of Day")
plt.ylabel("Day of the Week")
plt.yticks(ticks=range(0, 7), labels=['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'])  # Set y-axis labels
plt.show()


# **3.2.15** <font color = red>[2 marks]</font> <br>
# Analyse the variation of passenger counts across zones

# In[270]:


# How does passenger count vary across zones
passenger_count_per_zone = filtered_df2.groupby('zone')['passenger_count'].count().reset_index()
print(passenger_count_per_zone)


# In[271]:


passenger_count_per_zone['passenger_count_bins'] = pd.cut(passenger_count_per_zone['passenger_count'], bins=[0, 5000, 10000, 20000, 50000, float('inf')], labels=['0-5k', '5k-10k', '10k-20k', '20k-50k', '50k+'])
binned_zones = passenger_count_per_zone.groupby('passenger_count_bins', observed = False)['zone'].count().reset_index(name='zone_count')
plt.figure(figsize=(12, 6))
sns.barplot(data=binned_zones, x="passenger_count_bins", y="zone_count")
plt.title("Distribution of Zones by Passenger Count Bins")
plt.xlabel("Passenger Count Bins")
plt.ylabel("Number of Zones")
plt.tight_layout()
plt.show()


# In[272]:


# For a more detailed analysis, we can use the zones_with_trips GeoDataFrame
# Create a new column for the average passenger count in each zone.
average_passengers_per_zone = filtered_df2.groupby('zone')['passenger_count'].mean().reset_index()
zones_with_trips = pd.merge(zones_with_trips, average_passengers_per_zone, on='zone', how='left')
zones_with_trips = zones_with_trips.rename(columns={'passenger_count': 'avg_passenger_count'})
zones_with_trips['avg_passenger_count']


# Find out how often surcharges/extra charges are applied to understand their prevalance

# **3.2.16** <font color = red>[5 marks]</font> <br>
# Analyse the pickup/dropoff zones or times when extra charges are applied more frequently

# In[273]:


# How often is each surcharge applied?
trips_with_extra_charges = filtered_df2[filtered_df2['extra'] > 0]
pick_up_zone_frequency = trips_with_extra_charges.groupby(['zone', 'LocationID'])['extra'].count().reset_index(name = 'extra_charge_frequency')
print('Frequency of Pickup Zones with Extra Charges:')
print(pick_up_zone_frequency.sort_values('extra_charge_frequency' , ascending = False).head(20))


# In[274]:


trips_with_extra_charges = filtered_df2[filtered_df2['extra'] > 0]
drop_off_zone_frequency = trips_with_extra_charges.groupby(['zone', 'DOLocationID'])['extra'].count().reset_index(name = 'extra_charge_frequency')
print('Frequency of Dropoff Zones with Extra Charges:')
print(drop_off_zone_frequency.sort_values('extra_charge_frequency' , ascending = False).head(20))


# ## **4** Conclusion
# <font color = red>[15 marks]</font> <br>

# ### **4.1** Final Insights and Recommendations
# <font color = red>[15 marks]</font> <br>
# 
# Conclude your analyses here. Include all the outcomes you found based on the analysis.
# 
# Based on the insights, frame a concluding story explaining suitable parameters such as location, time of the day, day of the week etc. to be kept in mind while devising a strategy to meet customer demand and optimise supply.

# **4.1.1** <font color = red>[5 marks]</font> <br>
# Recommendations to optimize routing and dispatching based on demand patterns and operational inefficiencies

# JFK Airport, Times Square/Theatre District, East Village, West Village, and Greenwich Village South. According to study, these are some of the top zones with the greatest pickup rates per hour; therefore, additional taxis might be placed there to boost the NYC taxi company's earnings. 
# 
# According to trip trends, there are more journeys on Saturdays, which means that more taxis are being used to pick up passengers. The need to run more taxis throughout the day is shown by the higher average fare per mile in the morning, particularly around 2:00 pm, and the high income during the day. 
# 
# The World Trade Center, Yorkville East, and Yorkville West are areas with extremely high passenger counts, suggesting that many people use taxis there. As a result, more taxi routes might be established to these areas to facilitate more trips. 
# 
# •	261         1494
# •	262         3765
# •	263         5466
# 
# Compared to other pick-up LocationIDs, these three IDs exhibit a much greater number of journeys. By routing or dispatching more taxis to these IDs, it is possible to increase the number of trips and, consequently, the efficiency, which will immediately increase revenue. More cabs must be routed during the day because of the increased traffic and journeys. Additionally, if we look at the hours of the day, we find that the number of trips peaks at 18 hours, so the business should try to improve efficiency. 
# 
# According to the data analysis, October, May, and March have the most trips, therefore there is room to improve operational efficiency and the number of taxis available for pickup during these months.
# 
# Additionally, the data shows that weekday travels are higher than weekend journeys, so the company may want to consider adding additional taxis. 

# **4.1.2** <font color = red>[5 marks]</font> <br>
# 
# Suggestions on strategically positioning cabs across different zones to make best use of insights uncovered by analysing trip trends across time, days and months.

# During the day, more taxis should be stationed and operationalized in areas with high passenger counts, as this will increase revenue; more taxis should be placed in more residential areas and boroughs; in the evening, more taxis should be placed in midtown Manhattan areas where pick-ups are high; on weekdays, more taxis should be assigned to Penn Station, Wall Street, Midtown Manhattan; and because of the high pickups, a set percentage of taxis should be assigned to JKF airport.
# 
# For positioning at night, More taxis can be placed in these areas to boost nighttime travel and hence revenue since the data shows that the most popular pick-up locations at night are mostly JKF Airport, Clinton East, Lower East Side, Greenwich Village South Lower Manhattan, Williamsburg, and East Village. 

# **4.1.3** <font color = red>[5 marks]</font> <br>
# Propose data-driven adjustments to the pricing strategy to maximize revenue while maintaining competitive rates with other vendors.

# Regarding pricing strategy, the business may choose to impose a congestion surcharge on the routes with the highest traffic volumes and speeds. Higher fares are also charged for daytime excursions in order to maximize profits. You can provide customers discounts during periods when there aren't many journeys, particularly at night. 
# 
# According to the data, Vendor 2 charges the highest fee per mile, with the largest fare being charged during the late afternoon hours of 15 to 18 hours. As a result, Vendor 2 offers a premium service and keeps the fare high. For Vendor 1, the price remains consistent throughout the day and is reasonable. In order to maintain balanced fare rates per mile, the company may want to employ surge pricing. 
# 
# Take into account the times when there aren't many journeys, particularly on the weekends, and think about offering a discount to entice more people to use the taxi service. Since there is a significant link between fare and tip, a predetermined tip amount can be charged to the consumer upon reaching a specific fare level, increasing trip income in the process. 
# 
# Can think about providing clients with digital payments with a subscription. The business might think about charging more for digital payments during peak hours. Rides can be the same regardless of the amount of people using them because, according to the visualizations, passenger counts do not have a very strong association. Avoid charging extremely high surcharges during periods of high traffic for the benefit of your customers. 
# 
# Additionally, vendor 6 offers the lowest fare per mile during all hours, which encourages more customers to take rides during slow times when there aren't many trips in order to increase revenue. Given that credit cards are the most popular form of payment, a potential 3–5% credit card discount may be provided.
# 
